package kodutoo2.validation;

public interface  CardValidator {

    boolean validateCard(String socialId, String schoolId);
}
