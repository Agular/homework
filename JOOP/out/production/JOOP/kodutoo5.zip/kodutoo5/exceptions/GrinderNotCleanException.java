package kodutoo5.exceptions;

public class GrinderNotCleanException extends Exception {

    public GrinderNotCleanException() {}

    public GrinderNotCleanException(String message)
    {
        super(message);
    }
}
