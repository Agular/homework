package kodutoo3.card;

import java.math.BigDecimal;

public class OfflineCreditCard extends CreditCard {

    private final BigDecimal MINIMUM_OFFLINE_TRANSACTION_AMOUNT = new BigDecimal("1.00");
    private final BigDecimal MAXIMUM_OFFLINE_TRANSACTION_AMOUNT = new BigDecimal("50.00");
    private final BigDecimal OFFLINE_TRANSACTION_LIMIT = new BigDecimal("200.0");
    private final BigDecimal SERVICE_FEE = new BigDecimal("3.00");

    BigDecimal sumDoneOfflineTransactions = new BigDecimal("0");

    public OfflineCreditCard() {
    }

    public OfflineCreditCard(BigDecimal initialBalance) {
        super.setBalance(initialBalance);
    }

    public void makeOfflineTransaction(BigDecimal amount) {
        if (isOfflineTransactionAmountInBounds(amount)) {
            sumDoneOfflineTransactions = sumDoneOfflineTransactions.add(amount);
            addNecessaryFees();
        } else {
            System.out.println("Offline transaction amount: " + amount + " is out of bounds\n" +
                    "The amount must be between 1 and 50 euros.");
        }
    }

    private boolean isOfflineTransactionAmountInBounds(BigDecimal amount) {
        if (amount.compareTo(MINIMUM_OFFLINE_TRANSACTION_AMOUNT) >= 0 &&
                amount.compareTo(MAXIMUM_OFFLINE_TRANSACTION_AMOUNT) <= 0) {
            return true;
        }
        return false;
    }

    private void addNecessaryFees() {
        if (sumDoneOfflineTransactions.compareTo(OFFLINE_TRANSACTION_LIMIT) == 1) {
            sumDoneOfflineTransactions = sumDoneOfflineTransactions.add(SERVICE_FEE);
        }
    }

    public BigDecimal getSumDoneOfflineTransactions() {
        return sumDoneOfflineTransactions;
    }

    public void setSumDoneOfflineTransactions(BigDecimal sumDoneOfflineTransactions) {
        this.sumDoneOfflineTransactions = sumDoneOfflineTransactions;
    }
}
