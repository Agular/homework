package kodutoo3.card;

import java.math.BigDecimal;

public class CreditCard extends BankCard {

    private final  BigDecimal CREDIT_LIMIT = new BigDecimal("900.0");

    public CreditCard(){}

    public CreditCard (BigDecimal initialBalance){
        super.setBalance(initialBalance);
    }

    @Override
    public void makeTransaction(BigDecimal amount) throws RuntimeException{
        System.out.println(this.toString() +" Transaction amount: "+ amount);
        if(!transactionAmountExceedsCreditCardLimit(amount)){
            subtractBalance(amount);
            System.out.println(this.toString() + "Balance: " + getBalance());
        } else{
            System.out.println("Amount exceeds creditcard limit. Transaction cancelled");
        }

    }

    private boolean transactionAmountExceedsCreditCardLimit (BigDecimal amount){
        if(super.getBalance().subtract(amount).compareTo(CREDIT_LIMIT.negate()) == -1){
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Krediitkaart";
    }
}
