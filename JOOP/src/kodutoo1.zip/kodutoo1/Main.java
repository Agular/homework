package kodutoo1;

import kodutoo1.aircontroller.AirportController;

public class Main {
    public static void main(String[] args) {
        AirportController airportController = new AirportController();
        airportController.processTickets();
    }
}
