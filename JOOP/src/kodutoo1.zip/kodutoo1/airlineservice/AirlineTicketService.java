package kodutoo1.airlineservice;

public interface AirlineTicketService {
    public boolean hasNextBoardingPass();
    public BoardingPass getNextBoardingPass();
}
