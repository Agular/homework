package kodutoo1.airlineservice;

public interface BoardingPass {
    public String getPassengerFirstName();
    public String getPassengerLastName();
    public long getTicketCode();
}
