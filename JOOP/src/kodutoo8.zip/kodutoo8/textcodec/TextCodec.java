package kodutoo8.textcodec;

public interface TextCodec {

    String packMessage(String message);
}
